import * as i0 from "@angular/core";
import { Component, EventEmitter, Input, Output } from "@angular/core";
import { IonButton } from "@ionic/angular";
var MonsterCardComponent = class MonsterCardComponent {
	constructor() {
		this.imagen = "";
		this.titulo = "";
		this.texto = "";
		this.textoBoton = "Descubrir";
		this.botonPulsado = new EventEmitter();
	}
	alPulsar() {
		this.botonPulsado.emit();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.5",
			ngImport: i0,
			type: MonsterCardComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.5",
			type: MonsterCardComponent,
			isStandalone: true,
			selector: "lib-monster-card",
			inputs: {
				imagen: "imagen",
				titulo: "titulo",
				texto: "texto",
				textoBoton: "textoBoton"
			},
			outputs: { botonPulsado: "botonPulsado" },
			ngImport: i0,
			template: "<!-- Contenedor principal de la tarjeta -->\n<article class=\"tarjeta\">\n  <!-- Solo pintamos la imagen si la página nos ha pasado una -->\n  @if (imagen) {\n    <img class=\"tarjeta__imagen\" [src]=\"imagen\" [alt]=\"titulo\" />\n  }\n  <div class=\"tarjeta__cuerpo\">\n    <h2 class=\"tarjeta__titulo\">{{ titulo }}</h2>\n    <p class=\"tarjeta__texto\">{{ texto }}</p>\n    <!-- Botón de Ionic con el texto configurable -->\n    <ion-button class=\"tarjeta__boton\" (click)=\"alPulsar()\">\n      {{ textoBoton }}\n    </ion-button>\n  </div>\n</article>",
			styles: ["@charset \"UTF-8\";.tarjeta{background:var(--hui-superficie, #1c202a);border:3px double var(--hui-verde, #7fb069);border-radius:14px;box-shadow:0 0 18px #7fb06973,0 6px 14px #0009;overflow:hidden;margin:16px;transition:transform .15s ease,box-shadow .15s ease}.tarjeta:active{transform:scale(.97);box-shadow:0 0 22px #8b1a1acc}.tarjeta__imagen{width:100%;height:180px;object-fit:cover;display:block;border-bottom:3px solid var(--hui-rojo, #8b1a1a)}.tarjeta__cuerpo{padding:14px 16px 18px}.tarjeta__titulo{font-family:var(--hui-fuente-titulo, \"Creepster\", cursive);color:var(--hui-verde, #7fb069);letter-spacing:1px;margin:0 0 8px}.tarjeta__texto{font-family:var(--hui-fuente-texto, \"Lato\", sans-serif);color:#d8dde6;line-height:1.45}.tarjeta__boton{--background: var(--hui-amarillo, #e8d44d);--color: #0d0f14;font-weight:700}\n"],
			dependencies: [{
				kind: "component",
				type: IonButton,
				selector: "ion-button",
				inputs: [
					"buttonType",
					"color",
					"disabled",
					"download",
					"expand",
					"fill",
					"form",
					"href",
					"mode",
					"rel",
					"routerAnimation",
					"routerDirection",
					"shape",
					"size",
					"strong",
					"target",
					"type"
				],
				outputs: ["ionFocus", "ionBlur"]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: MonsterCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-monster-card",
			standalone: true,
			imports: [IonButton],
			template: "<!-- Contenedor principal de la tarjeta -->\n<article class=\"tarjeta\">\n  <!-- Solo pintamos la imagen si la página nos ha pasado una -->\n  @if (imagen) {\n    <img class=\"tarjeta__imagen\" [src]=\"imagen\" [alt]=\"titulo\" />\n  }\n  <div class=\"tarjeta__cuerpo\">\n    <h2 class=\"tarjeta__titulo\">{{ titulo }}</h2>\n    <p class=\"tarjeta__texto\">{{ texto }}</p>\n    <!-- Botón de Ionic con el texto configurable -->\n    <ion-button class=\"tarjeta__boton\" (click)=\"alPulsar()\">\n      {{ textoBoton }}\n    </ion-button>\n  </div>\n</article>",
			styles: ["@charset \"UTF-8\";.tarjeta{background:var(--hui-superficie, #1c202a);border:3px double var(--hui-verde, #7fb069);border-radius:14px;box-shadow:0 0 18px #7fb06973,0 6px 14px #0009;overflow:hidden;margin:16px;transition:transform .15s ease,box-shadow .15s ease}.tarjeta:active{transform:scale(.97);box-shadow:0 0 22px #8b1a1acc}.tarjeta__imagen{width:100%;height:180px;object-fit:cover;display:block;border-bottom:3px solid var(--hui-rojo, #8b1a1a)}.tarjeta__cuerpo{padding:14px 16px 18px}.tarjeta__titulo{font-family:var(--hui-fuente-titulo, \"Creepster\", cursive);color:var(--hui-verde, #7fb069);letter-spacing:1px;margin:0 0 8px}.tarjeta__texto{font-family:var(--hui-fuente-texto, \"Lato\", sans-serif);color:#d8dde6;line-height:1.45}.tarjeta__boton{--background: var(--hui-amarillo, #e8d44d);--color: #0d0f14;font-weight:700}\n"]
		}]
	}],
	propDecorators: {
		imagen: [{ type: Input }],
		titulo: [{ type: Input }],
		texto: [{ type: Input }],
		textoBoton: [{ type: Input }],
		botonPulsado: [{ type: Output }]
	}
});
export { MonsterCardComponent };

//# sourceMappingURL=halloween-ui.mjs.map